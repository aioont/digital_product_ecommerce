# wifi-bruteforce
Create password for brutefore from accepting string.
This java program generate every possible combinations of string from input character and store this combination to passwords.txt text files.

# How to download
`git clone https://github.com/aioont/wifi-bruteforce.git`

# How to run
`javac pass.java && java pass`

# Example 

$ javac pass.java && java pass

!!! If there is passwords.txt in same folder of program remove it to avoid appending of new passwords to prevoius passwords.txt file

Enter characters (a-Z , 0-9 , ~-) : 1234

[ 340 ]   passwords are generated and saved to passwords.txt 
